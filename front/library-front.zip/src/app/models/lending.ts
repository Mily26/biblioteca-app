export interface Lending {
    id: number;
    userId: number;
    bookId: number;
    dateOut: number;
    dateReturn: number;
}