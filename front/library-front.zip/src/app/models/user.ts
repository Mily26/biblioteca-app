export interface User {
    id: string;
    email: string;
    name: string;
    lastNameP: string;
    lastNameM: string;
    address: string;
    phone: string;
    sanctions: string;
    sancMoney: string;
}