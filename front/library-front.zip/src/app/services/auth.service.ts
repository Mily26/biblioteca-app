import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { HttpClient } from '@angular/common/http';
import { configs } from "../configs";
import { User } from "../models/user";

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    constructor(private http: HttpClient){

    }
    private _isLoggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false)
    public $isLoggedIn = this._isLoggedIn.asObservable()

    public validateUser(email: string, password: string) {
      /*  let body = {email, password};
        this.http.post<User>(configs.BACKEND_BASE_URL + "/api/user/login", body)
            .subscribe(user => {
                if(user && user.email != null) {*/
                    this._isLoggedIn.next(true);/*
                }
                else {
                    this._isLoggedIn.next(false);
                }
            })*/
    }
}