export const configs = {
    BACKEND_BASE_URL: 'http://localhost:8080'
}