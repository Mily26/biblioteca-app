import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  email: FormControl;
  password: FormControl;
  name: FormControl;
  lastNameP: FormControl;
  lastNameM: FormControl;
  address: FormControl;

  constructor() { 
    this.email = new FormControl('', [Validators.required, Validators.email]);
    this.password = new FormControl('', [Validators.required, Validators.minLength(8)]);
    this.name = new FormControl('', [Validators.required, Validators.minLength(3)]);
    this.lastNameP = new FormControl('', [Validators.required, Validators.minLength(3)]);
    this.lastNameM = new FormControl('', [Validators.required, Validators.minLength(3)]);
    this.address = new FormControl('', [Validators.required, Validators.minLength(3)]);
  }

  ngOnInit(): void {
  }

  registerUser() {
    const userData = {
      email: this.email.value,
      password: this.password.value,
      name: this.name.value,
      lastNameP: this.lastNameP.value,
      lastNameM: this.lastNameM.value,
      address: this.address.value
    };

    console.log(userData);
  }

}
